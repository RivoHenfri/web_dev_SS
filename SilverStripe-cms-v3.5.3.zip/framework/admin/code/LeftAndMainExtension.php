<?php

/**
 * Plug-ins for additional functionality in your LeftAndMain classes.
 *
 * @package framework
 * @subpackage admin
 */
abstract class LeftAndMainExtension extends Extension {

	public function init() {
	}

	public function accessedCMS() {
	}

	public function augmentNewSiteTreeItem(&$item) {
	}

}
